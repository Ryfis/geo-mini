import React from 'react';
import { useNavigate } from 'react-router-dom';
import MapView from './MapView';
import { useAuth } from '../contexts/AuthContext';

export default function MapViewWrapper() {
  console.log('🗺️ MapViewWrapper Rendered');
  const navigate = useNavigate();
  const { user } = useAuth();
  const [unreadMessageCount, setUnreadMessageCount] = React.useState(0);
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    // Имитируем загрузку данных пользователя
    // В реальном приложении здесь были бы запросы к API
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  }, []);

  const handleNavigateToMessages = () => {
    navigate('/messages');
  };

  const handleNavigateToProfile = () => {
    navigate('/profile');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Загрузка приложения...</p>
        </div>
      </div>
    );
  }

  return (
    <MapView
      unreadMessageCount={unreadMessageCount}
      onNavigateToMessages={handleNavigateToMessages}
      onNavigateToProfile={handleNavigateToProfile}
    />
  );
}