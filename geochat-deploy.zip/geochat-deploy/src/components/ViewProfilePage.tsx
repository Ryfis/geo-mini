import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, Profile, Friendship } from '../lib/supabase';
import { ArrowLeft, UserPlus, MessageSquare, UserCheck, User } from 'lucide-react';

interface ViewProfilePageProps {
  userId: string;
  onBack: () => void;
  onStartChat: (profile: Profile) => void;
}

export function ViewProfilePage({ userId, onBack, onStartChat }: ViewProfilePageProps) {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [friendship, setFriendship] = useState<Friendship | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProfile();
    loadFriendship();
  }, [userId]);

  const loadProfile = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    setProfile(data);
    setLoading(false);
  };

  const loadFriendship = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('friendships')
      .select('*')
      .or(`and(user_id.eq.${user.id},friend_id.eq.${userId}),and(user_id.eq.${userId},friend_id.eq.${user.id})`)
      .maybeSingle();

    setFriendship(data);
  };

  const handleSendFriendRequest = async () => {
    if (!user || !profile) return;

    const { error } = await supabase.from('friendships').insert([
      {
        user_id: user.id,
        friend_id: profile.id,
        status: 'pending',
      },
    ]);

    if (error) {
      console.error('Error sending friend request:', error);
      alert('Failed to send friend request');
    } else {
      alert('Friend request sent!');
      loadFriendship();
    }
  };

  const handleAcceptRequest = async () => {
    if (!friendship) return;

    const { error } = await supabase
      .from('friendships')
      .update({ status: 'accepted', updated_at: new Date().toISOString() })
      .eq('id', friendship.id);

    if (error) {
      console.error('Error accepting request:', error);
      alert('Failed to accept request');
    } else {
      loadFriendship();
    }
  };

  const handleStartChat = () => {
    if (profile) {
      onStartChat(profile);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-lg text-gray-600">Loading...</div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white  sticky top-0 z-10">
          <div className="px-4 py-3 flex items-center">
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-full transition"
            >
              <ArrowLeft size={24} />
            </button>
          </div>
        </div>
        <div className="text-center py-12 text-gray-600">User not found</div>
      </div>
    );
  }

  const isOwnProfile = user?.id === userId;
  const isFriend = friendship?.status === 'accepted';
  const hasPendingRequest = friendship?.status === 'pending';
  const receivedRequest = friendship?.friend_id === user?.id && hasPendingRequest;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white  sticky top-0 z-10">
        <div className="px-4 py-3 flex items-center justify-between">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-full transition"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold">Profile</h1>
          <div className="w-10"></div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-6">
        <div className="bg-white rounded-2xl  p-6">
          <div className="flex flex-col items-center mb-6">
            <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden mb-4">
              {profile.avatar_url ? (
                <img
                  src={profile.avatar_url}
                  alt={profile.username}
                  className="w-full h-full object-cover"
                />
              ) : (
                <User size={48} className="text-gray-400" />
              )}
            </div>
            <h2 className="text-2xl font-bold mb-2">{profile.username}</h2>
            {profile.bio && (
              <p className="text-gray-600 text-center">{profile.bio}</p>
            )}
          </div>

          {!isOwnProfile && (
            <div className="space-y-3">
              {!friendship && (
                <button
                  onClick={handleSendFriendRequest}
                  className="w-full bg-blue-500 text-white py-3 rounded-lg font-semibold hover:bg-blue-600 transition flex items-center justify-center gap-2"
                >
                  <UserPlus size={20} />
                  Add Friend
                </button>
              )}

              {receivedRequest && (
                <button
                  onClick={handleAcceptRequest}
                  className="w-full bg-green-500 text-white py-3 rounded-lg font-semibold hover:bg-green-600 transition flex items-center justify-center gap-2"
                >
                  <UserCheck size={20} />
                  Accept Friend Request
                </button>
              )}

              {hasPendingRequest && !receivedRequest && (
                <div className="w-full bg-gray-100 text-gray-600 py-3 rounded-lg font-semibold text-center">
                  Friend request pending
                </div>
              )}

              {isFriend && (
                <button
                  onClick={handleStartChat}
                  className="w-full bg-green-500 text-white py-3 rounded-lg font-semibold hover:bg-green-600 transition flex items-center justify-center gap-2"
                >
                  <MessageSquare size={20} />
                  Send Message
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
