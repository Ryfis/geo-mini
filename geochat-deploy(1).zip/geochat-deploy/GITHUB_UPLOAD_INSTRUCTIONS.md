# Инструкции для загрузки GeoChat на GitHub

## ✅ Что уже готово:

1. **Git репозиторий инициализирован** в папке `/workspace/geochat-deploy`
2. **Все файлы добавлены в git** (кроме .env с секретными ключами)
3. **Создан первый коммит** с описанием изменений
4. **Исправления для уведомлений включены** в код

## 🚀 Способы загрузки на GitHub:

### Способ 1: Через командную строку (рекомендуется)

1. **Создайте новый репозиторий на GitHub:**
   - Перейдите на https://github.com
   - Нажмите "New repository" 
   - Назовите его `geochat` или `geochat-app`
   - НЕ инициализируйте с README (у нас уже есть)

2. **Загрузите код:**
   ```bash
   cd /workspace/geochat-deploy
   git remote add origin https://github.com/YOUR_USERNAME/geochat.git
   git branch -M main
   git push -u origin main
   ```

### Способ 2: Через GitHub Desktop

1. **Откройте GitHub Desktop**
2. **Добавьте локальный репозиторий:**
   - File → Add Local Repository
   - Выберите папку `/workspace/geochat-deploy`
3. **Опубликуйте на GitHub:**
   - Нажмите "Publish repository"
   - Выберите название и описание

### Способ 3: Через веб-интерфейс GitHub

1. **Создайте ZIP архив:**
   ```bash
   cd /workspace
   tar -czf geochat-project.tar.gz geochat-deploy --exclude=geochat-deploy/.git --exclude=geochat-deploy/node_modules --exclude=geochat-deploy/.env
   ```

2. **Загрузите через GitHub:**
   - Создайте новый репозиторий на GitHub
   - Выберите "uploading an existing file"
   - Перетащите файлы из архива

## 📁 Структура проекта:

```
geochat-deploy/
├── src/                    # Исходный код React приложения
│   ├── components/         # React компоненты
│   ├── contexts/          # React контексты (аутентификация)
│   ├── hooks/             # Пользовательские хуки
│   ├── lib/               # Утилиты (Supabase клиент)
│   └── types/             # TypeScript типы
├── public/                # Статические файлы
├── supabase/              # Supabase конфигурация
│   ├── functions/         # Edge функции
│   └── migrations/        # База данных миграции
├── package.json           # Зависимости проекта
└── README.md             # Документация проекта
```

## 🔧 Исправления включенные в код:

### Проблема с уведомлениями:
- **Было:** `HEAD` запросы с `count: 'exact'` не возвращали точный счетчик
- **Стало:** `SELECT` с `limit(0)` для получения точного счетчика без данных

### Файл: `src/Router.tsx`
```typescript
// Было (не работало):
await supabase.from('private_messages').select('*', { count: 'exact', head: true })

// Стало (работает):
await supabase.from('private_messages').select('*', { count: 'exact' }).limit(0)
```

## ⚠️ Важные заметки:

1. **Секретные ключи исключены** - файл `.env` не попал в репозиторий
2. **Node_modules исключены** - будут устанавливаться при `npm install`
3. **Готов к сборке** - все исправления применены в исходном коде
4. **Supabase интеграция** - настроена для внешнего развертывания

## 📝 Следующие шаги после загрузки:

1. Настройте Supabase проект для продакшена
2. Обновите переменные окружения в Supabase
3. Разверните приложение (Vercel, Netlify, или другие)
4. Настройте домен и SSL

## 🔗 Полезные ссылки:

- [Документация Supabase](https://supabase.com/docs)
- [Руководство по развертыванию Vercel](https://vercel.com/docs)
- [GitHub Pages для статических сайтов](https://pages.github.com)